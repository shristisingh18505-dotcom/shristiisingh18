import os
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm

def report_card(output_dir, student, courses_data):
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, f"report_{student.roll_no}.pdf")
    c = canvas.Canvas(path, pagesize=A4)

    c.setFont("Helvetica-Bold", 16)
    c.drawString(20*mm, 280*mm, "EduTrack School")
    c.setFont("Helvetica", 11)
    c.drawString(20*mm, 272*mm, f"Report Card — {student.name} (Roll {student.roll_no})  Class: {student.std or '-'}")
    c.line(20*mm, 270*mm, 190*mm, 270*mm)

    y = 260*mm
    c.setFont("Helvetica-Bold", 12)
    c.drawString(20*mm, y, "Course")
    c.drawRightString(120*mm, y, "Teacher")
    c.drawRightString(160*mm, y, "Attendance %")
    c.drawRightString(190*mm, y, "Avg Score")
    y -= 6*mm
    c.setFont("Helvetica", 11)
    for row in courses_data:
        c.drawString(20*mm, y, row["course"])
        c.drawRightString(120*mm, y, row["teacher"])
        c.drawRightString(160*mm, y, f"{row['attendance_pct']:.0f}%")
        c.drawRightString(190*mm, y, f"{row['avg_score']:.1f}")
        y -= 6*mm

    c.showPage()
    c.save()
    return path
